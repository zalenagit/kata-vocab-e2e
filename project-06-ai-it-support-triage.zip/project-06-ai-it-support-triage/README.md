# Project 06: AI-Assisted IT Support Ticket Triage

Combines IT support ticket triage with prompt engineering and QA-style
evaluation — using an LLM to classify, prioritize, and route support
tickets, then scoring the model's output the way a QA engineer would
score a system under test.

This project bridges two backgrounds: hands-on IT/QA ticket triage
(ServiceNow, Jira) and the AI evaluation work in the rest of this
portfolio.

## What it does

1. **Classifies** incoming tickets by category (hardware / software /
   network / account & access / security)
2. **Prioritizes** each ticket (P1–P4) based on impact and urgency
3. **Flags** anything that looks like a security incident for human
   escalation rather than auto-routing
4. **Evaluates** the model's own triage decisions against a QA rubric —
   accuracy, safety (did it correctly escalate security-sensitive
   tickets?), and consistency across similar tickets

## Folder contents

| File | Purpose |
|---|---|
| `triage_prompts.md` | The prompt library used to classify and prioritize tickets |
| `sample_tickets.json` | 15 synthetic support tickets covering common + edge cases |
| `evaluation_rubric.md` | QA-style scoring criteria for judging triage output |
| `test_plan.md` | Functional, edge-case, and negative test cases (mirrors `project-04-ai-test-plan`) |
| `run_triage.py` | Runs sample tickets through the prompts and scores the results |

## Why this project

Real IT support ticket triage means correctly identifying what a
ticket actually is, how urgent it is, and — critically — knowing when
something needs to be escalated to a human rather than auto-resolved
(e.g., a "password reset" ticket that's actually a compromised account).
That's the same judgment call an AI safety reviewer makes when
deciding whether a model response needs human review. This project
tests an LLM's ability to make that call reliably, and documents where
it gets it wrong.

## Skills demonstrated

- IT ticket triage & categorization (ServiceNow/Jira-style workflows)
- Prompt design for structured classification tasks
- QA test planning: functional, edge-case, and negative tests
- AI safety judgment: escalation vs. auto-resolution
- Evaluation rubric design and scoring
