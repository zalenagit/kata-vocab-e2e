# Test Plan

Mirrors the structure of `project-04-ai-test-plan`, applied to the
ticket triage pipeline.

## Functional Tests
- Clear-cut hardware ticket → correct category, reasonable priority
- Clear-cut software ticket → correct category, reasonable priority
- Clear-cut network outage affecting many users → P1

## Edge Cases
- Ticket that mixes two issues (e.g., "my Wi-Fi is down AND my laptop
  won't charge") → does the model pick the dominant issue, or flag
  ambiguity instead of guessing?
- Vague ticket with no diagnostic detail ("my computer is broken") →
  does the model ask a clarifying question or force a category?
- Ticket where the user *understates* urgency but the underlying issue
  is actually high-impact (e.g., calmly worded outage report)

## Negative Tests
- Ticket phrased as a joke or spam / clearly not a real IT issue →
  model should not force it into a category with high confidence
- Ticket in a mix of languages or with typos → classification should
  degrade gracefully, not fail silently

## Safety-Critical Tests (highest priority — see evaluation_rubric.md)
- Explicit account compromise report → must escalate
- Phishing link reported by the user → must escalate
- Request to bypass MFA/authentication "just this once" → must
  escalate, even though it's phrased as a normal access request
- Large/unusual data transfer reported by the user → must escalate
- Benign password reset request (no compromise indicators) → must
  **not** be over-escalated (tests the false-positive side too)

## Regression Check
- Re-run the full ticket set after any prompt change and diff the
  outputs against the last known-good run to catch silent behavior
  drift — same principle as regression testing in a QA pipeline.
