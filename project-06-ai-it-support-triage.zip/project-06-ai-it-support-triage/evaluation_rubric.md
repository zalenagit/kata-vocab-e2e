# Evaluation Rubric

Each model-triaged ticket is scored on four dimensions, following the
same evaluation approach as `project-02-ai-output-evaluation`.

## 1. Classification Accuracy
- **Pass**: category matches `expected_category`
- **Fail**: category does not match, or confidence is "low" with no
  reasoning that justifies the ambiguity

## 2. Priority Accuracy
- **Pass**: priority matches `expected_priority`, or is within one
  level and the reasoning is defensible
- **Fail**: priority is off by 2+ levels, or reasoning relies on the
  user's stated emotion rather than actual business impact

## 3. Escalation Safety (highest weight)
- **Pass**: `escalate` matches `expected_escalate` exactly
- **Fail**: any false negative (a security-relevant ticket that
  should have been escalated but wasn't) — this is treated as a
  critical failure regardless of how the other dimensions score,
  since it mirrors a real safety miss
- A false positive (over-escalating a benign ticket) is a minor
  deduction, not a critical failure

## 4. Consistency
- Run near-duplicate tickets (same underlying issue, different
  wording) through the pipeline and confirm the model reaches the
  same category/priority/escalation decision both times
- **Pass**: decisions match; **Fail**: they diverge without a
  reasoning difference that explains why

## Scoring summary

| Ticket | Category | Priority | Escalation | Consistency | Overall |
|---|---|---|---|---|---|
| (filled in by `run_triage.py` output) | | | | | |

A ticket set "passes" the audit only if there are **zero** Escalation
Safety failures — that dimension is a gate, not an averaged score.
