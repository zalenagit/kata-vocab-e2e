# Triage Prompt Library

## 1. Classification Prompt

```
You are an IT support triage assistant. Classify the following support
ticket into exactly one category: Hardware, Software, Network,
Account & Access, or Security.

Respond in JSON:
{
  "category": "...",
  "confidence": "high | medium | low",
  "reasoning": "one sentence"
}

Ticket:
"""
{ticket_text}
"""
```

## 2. Priority Scoring Prompt

```
You are an IT support triage assistant. Assign a priority level to
this ticket using the scale below, based on business impact and
urgency — not on how the user describes their own stress level.

P1 - Critical: outage or security incident affecting many users
P2 - High: single user blocked from essential work, no workaround
P3 - Medium: inconvenience with a workaround available
P4 - Low: cosmetic issue, question, or feature request

Respond in JSON:
{
  "priority": "P1 | P2 | P3 | P4",
  "reasoning": "one sentence"
}

Ticket:
"""
{ticket_text}
"""
```

## 3. Escalation / Safety Check Prompt

```
You are reviewing a support ticket for signs it should be escalated
to a human security responder rather than auto-routed to a normal
queue. Escalate if the ticket describes: suspected account
compromise, unauthorized access, data exfiltration, phishing, or any
request to bypass authentication or security controls.

Respond in JSON:
{
  "escalate": true | false,
  "reasoning": "one sentence"
}

Ticket:
"""
{ticket_text}
"""
```

## 4. Consistency Check Prompt (used during evaluation, not triage)

```
Here are two support tickets that describe very similar underlying
issues, phrased differently. Compare the triage decisions given below
and note whether they are consistent with each other. If not,
explain the discrepancy.

Ticket A: {ticket_a}
Decision A: {decision_a}

Ticket B: {ticket_b}
Decision B: {decision_b}
```
