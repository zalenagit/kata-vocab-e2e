"""
run_triage.py

Runs sample_tickets.json through the triage prompts and scores the
results against evaluation_rubric.md.

Usage:
    python run_triage.py --mock          # no API key needed, uses a
                                          # simple rule-based stand-in
                                          # so the pipeline is runnable
                                          # end-to-end for demo purposes
    python run_triage.py --live          # calls the Anthropic API
                                          # (requires ANTHROPIC_API_KEY)
"""

import json
import os
import re
import argparse
from pathlib import Path

HERE = Path(__file__).parent
TICKETS_PATH = HERE / "sample_tickets.json"

SECURITY_KEYWORDS = [
    "logged into my email", "phishing", "click a link", "bypass mfa",
    "bypass authentication", "unauthorized", "data transfer",
    "external drive", "someone else logged", "compromise",
]

NETWORK_KEYWORDS = ["wifi", "wi-fi", "vpn", "internet", "connection", "network"]
HARDWARE_KEYWORDS = ["laptop", "monitor", "printer", "headset", "won't turn on", "toner"]
ACCOUNT_KEYWORDS = ["password", "access", "locked out", "account"]


def mock_classify(text: str) -> dict:
    """A simple keyword-based stand-in for the LLM, so this script runs
    end-to-end without an API key. Replace with real API calls for the
    live version (see call_llm() below)."""
    t = text.lower()

    escalate = any(k in t for k in SECURITY_KEYWORDS)

    if escalate:
        category = "Security"
    elif any(k in t for k in NETWORK_KEYWORDS):
        category = "Network"
    elif any(k in t for k in HARDWARE_KEYWORDS):
        category = "Hardware"
    elif any(k in t for k in ACCOUNT_KEYWORDS):
        category = "Account & Access"
    else:
        category = "Software"

    if escalate:
        priority = "P1"
    elif "everyone" in t or "floor" in t or "nobody" in t:
        priority = "P1"
    elif "meeting in" in t or "won't turn on" in t:
        priority = "P2"
    elif "not urgent" in t or "just noting" in t or "just wanted to flag" in t:
        priority = "P4"
    else:
        priority = "P3"

    return {"category": category, "priority": priority, "escalate": escalate}


def call_llm(prompt: str) -> dict:
    """Placeholder for a real API call, e.g. to the Anthropic API.
    Fill this in with your own request/response handling and parse the
    JSON the model returns."""
    raise NotImplementedError(
        "Wire this up to your LLM of choice for --live mode. "
        "See triage_prompts.md for the exact prompts to send."
    )


def score_ticket(ticket: dict, result: dict) -> dict:
    scores = {
        "category_pass": result["category"] == ticket["expected_category"],
        "priority_pass": result["priority"] == ticket["expected_priority"],
        "escalation_pass": result["escalate"] == ticket["expected_escalate"],
    }
    # Escalation is a gate, not an averaged score (see evaluation_rubric.md)
    scores["critical_failure"] = (
        ticket["expected_escalate"] and not result["escalate"]
    )
    return scores


def main():
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--mock", action="store_true")
    mode.add_argument("--live", action="store_true")
    args = parser.parse_args()

    tickets = json.loads(TICKETS_PATH.read_text())

    total = len(tickets)
    category_correct = 0
    priority_correct = 0
    escalation_correct = 0
    critical_failures = []

    for ticket in tickets:
        if args.mock:
            result = mock_classify(ticket["text"])
        else:
            # Wire up triage_prompts.md + call_llm() here for live mode
            result = call_llm(ticket["text"])

        scores = score_ticket(ticket, result)
        category_correct += scores["category_pass"]
        priority_correct += scores["priority_pass"]
        escalation_correct += scores["escalation_pass"]
        if scores["critical_failure"]:
            critical_failures.append(ticket["id"])

        status = "PASS" if all([scores["category_pass"], scores["priority_pass"], scores["escalation_pass"]]) else "FAIL"
        print(f"{ticket['id']}: {status} | got={result} expected="
              f"{{'category': '{ticket['expected_category']}', "
              f"'priority': '{ticket['expected_priority']}', "
              f"'escalate': {ticket['expected_escalate']}}}")

    print("\n--- Summary ---")
    print(f"Category accuracy:   {category_correct}/{total}")
    print(f"Priority accuracy:   {priority_correct}/{total}")
    print(f"Escalation accuracy: {escalation_correct}/{total}")

    if critical_failures:
        print(f"\n⚠️  CRITICAL: missed escalation on {len(critical_failures)} "
              f"ticket(s): {', '.join(critical_failures)}")
        print("This is a gating failure per evaluation_rubric.md.")
    else:
        print("\n✅ No missed escalations — safety gate passed.")


if __name__ == "__main__":
    main()
